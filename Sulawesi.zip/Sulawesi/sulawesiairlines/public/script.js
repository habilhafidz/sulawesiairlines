function toggleMenu() {
    const menu = document.getElementById("menu");
    menu.classList.toggle("open");
}

function showNotification(message, success = true, elementId = 'login-notification') {
    const notification = document.getElementById(elementId);
    notification.textContent = message;
    notification.className = `notification ${success ? 'show' : 'error'}`; // Menambahkan kelas berdasarkan status
    notification.classList.remove('hidden');

    // Tampilkan notifikasi
    setTimeout(() => {
        notification.classList.remove('show');
        notification.classList.add('hidden');
    }, 3000);
}

function login() {
    const email = document.getElementById('emailInput').value;
    const password = document.getElementById('passwordInput').value;

    // Simulasi login (kamu bisa menghubungkannya dengan backend)
    if (email === "user@example.com" && password === "password123") {
        showNotification('Login Berhasil', true);
        window.location.href = "/?loggedIn=true"; // Redirect ke halaman utama
    } else {
        showNotification('Login gagal! Email atau password salah.', false);
    }
}

// Menangani pengiriman data login
async function login() {
    const email = document.getElementById('emailInput').value;
    const password = document.getElementById('passwordInput').value;

    try {
        const response = await fetch('/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email, password }),
        });

        if (!response.ok) {
            const errorData = await response.json();
            showNotification(errorData.message, false);
            return;
        }

        const data = await response.json();
        showNotification(data.message, true); // Tampilkan notifikasi sukses
        setTimeout(() => {
            window.location.href = data.redirect; // Redirect setelah login berhasil
        }, 2000);
    } catch (error) {
        console.error('Error:', error);
        showNotification("Login gagal! Terjadi kesalahan dalam koneksi.", false);
    }
}

function showLoginError(message) {
    showErrorNotification(message || "Login gagal! Email atau password salah.");
}

document.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('loggedIn') === 'true') {
        showNotification('Login Successful', true); // Tampilkan notifikasi sukses
    }
});

// Fungsi untuk menunjukkan pesan error
function showError(message) {
    const errorMessageElement = document.getElementById('errorMessage');
    if (errorMessageElement) {
        errorMessageElement.innerText = message; // Set pesan error
        errorMessageElement.classList.remove('hidden'); // Tampilkan elemen
    }
}

// Fungsi untuk mengirim kode verifikasi
function sendVerificationCode(email) {
    fetch('/send-verification-code', {
        method: 'POST',
        body: JSON.stringify({ email }),
        headers: {
            'Content-Type': 'application/json',
        },
    })
    .then(response => {
        if (!response.ok) {
            // Menampilkan notifikasi jika gagal
            return response.json().then(data => {
                showNotification('Register Gagal: ' + data.message, false);
            });
        }
        // Jika berhasil, tampilkan notifikasi keberhasilan
        showNotification('Kode verifikasi telah dikirim!', true);
    })
    .catch(error => {
        showNotification('Register Gagal: ' + error.message, false);
    });
}

// Contoh penggunaan fungsi showError
function validateVerificationCode() {
    // Logika validasi kode verifikasi
    const verificationCode = document.getElementById('verificationCode').value;
    if (!isValid(verificationCode)) { // Contoh kondisi validasi
        showError('Kode verifikasi tidak valid!');
    }
}

document.getElementById('validate-code-button').addEventListener('click', function() {
    validateVerificationCode(); // Panggil fungsi ini saat tombol diklik
});

// Menangani pengiriman kode verifikasi
document.getElementById('registerForm')?.addEventListener('submit', function(event) {
    event.preventDefault();
    const email = event.target.email.value;

    fetch('/send-verification-code', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email })
    })
    .then(response => {
        if (response.ok) {
            alert('Kode verifikasi telah dikirim ke email Anda.');
            document.getElementById('verificationForm').style.display = 'block';
            document.getElementById('registerForm').style.display = 'none';
        } else {
            response.json().then(errorData => {
                showErrorNotification('Gagal mengirim kode verifikasi: ' + errorData.message);
            });
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showErrorNotification('Gagal mengirim kode verifikasi: Terjadi kesalahan dalam koneksi.');
    });
});

// Menangani pendaftaran setelah mendapatkan kode verifikasi
document.getElementById('verificationForm')?.addEventListener('submit', function(event) {
    event.preventDefault();

    const email = document.getElementById('registerForm').email.value;
    const nickname = event.target.nickname.value;
    const verificationCode = event.target.verificationCode.value;
    const password = event.target.password.value;

    fetch('/register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email, nickname, verificationCode, password })
    })
    .then(response => {
        if (response.ok) {
            return response.json();
        }
        return response.json().then(errorData => {
            throw new Error(errorData.message);
        });
    })
    .then(data => {
        console.log('Registration successful:', data);
        showNotification('Register Berhasil!', true, 'register-notification'); // Notifikasi berhasil
        window.location.href = '/login';
    })
    .catch(error => {
        console.error('Error:', error);
        showNotification('Registrasi gagal: ' + error.message, false, 'register-notification'); // Notifikasi gagal dengan keterangan
    });
});

document.getElementById('loginForm')?.addEventListener('submit', function(event) {
    event.preventDefault();

    const email = event.target.email.value;
    const password = event.target.password.value;

    fetch('/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email, password })
    })
    .then(response => {
        if (response.ok) {
            return response.json();
        }
        return response.json().then(errorData => {
            throw new Error(errorData.message);
        });
    })
    .then(data => {
        console.log('Login successful:', data);
        showNotification('Login Berhasil!', true, 'login-notification'); // Notifikasi login berhasil
        window.location.href = '/main'; // Redirect ke halaman utama
    })
    .catch(error => {
        console.error('Error:', error);
        showNotification('Login gagal: ' + error.message, false, 'login-notification'); // Notifikasi login gagal
    });
});

const registerForm = document.getElementById('registerForm');
const verificationForm = document.getElementById('verificationForm');

registerForm.addEventListener('submit', (event) => {
    event.preventDefault();
    // Kirim email verifikasi (hubungkan ke server)
    console.log("Mengirim kode verifikasi ke email...");

    // Tampilkan form kode verifikasi setelah email dikirim
    registerForm.style.display = 'none';
    verificationForm.style.display = 'block';
});

verificationForm.addEventListener('submit', (event) => {
    event.preventDefault();
    const verificationCode = document.querySelector('input[name="verificationCode"]').value;
    const nickname = document.querySelector('input[name="nickname"]').value;
    const password = document.querySelector('input[name="password"]').value;

    // Verifikasi kode dan simpan data pengguna
    console.log("Verifikasi kode:", verificationCode);
    // Jika sukses, lakukan tindakan selanjutnya, misalnya redirect
});
