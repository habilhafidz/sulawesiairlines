const express = require('express');
const path = require('path');
const mysql = require('mysql2');
const bcrypt = require('bcrypt');
const nodemailer = require('nodemailer');
const crypto = require('crypto');
require('dotenv').config({ path: 'aaa.env' }); // Memungkinkan penggunaan variabel lingkungan

console.log('DB_USER:', process.env.DB_USER);
console.log('DB_PASSWORD:', process.env.DB_PASSWORD);
console.log('DB_NAME:', process.env.DB_NAME);

const app = express();
const port = 3000;

// Middleware dan rute Anda di sini
app.listen(port, () => {
    console.log(`Terhubung ke server http://localhost:${port}/`);
});

// Middleware untuk parsing data dari body
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Middleware untuk melayani file statis dari folder 'public'
app.use(express.static(path.join(__dirname, 'public')));

// Koneksi ke database
const connection = mysql.createConnection({
    host: process.env.DB_HOST,       // Menggunakan variabel dari .env
    user: process.env.DB_USER,       // Menggunakan variabel dari .env
    password: process.env.DB_PASSWORD, // Menggunakan variabel dari .env
    database: process.env.DB_NAME    // Menggunakan variabel dari .env
});

// Menghubungkan ke database
connection.connect((err) => {
    if (err) {
        console.error('Error connecting to MySQL:', err.stack);
        return;
    }
    console.log('Terhubung ke database MySQL sebagai ID ' + connection.threadId);
});

// Rute untuk halaman utama
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

// Rute untuk halaman pendaftaran
app.get('/register', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'register.html'));
});

// Temporary storage for verification codes
const verificationCodes = {};

// Fungsi untuk memeriksa kekuatan password
function isPasswordStrong(password) {
    const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    return regex.test(password);
}

// Menangani data pendaftaran
app.post('/register', (req, res) => {
    const { email, nickname, verificationCode, password } = req.body;

    // Validasi kode verifikasi
    console.log(`Verifying registration for email: ${email}`);
    if (verificationCode !== verificationCodes[email]) {
        console.log('Invalid verification code');
        return res.status(400).json({ message: 'Kode verifikasi tidak valid!' });
    }

    // Validasi kekuatan password
    if (!isPasswordStrong(password)) {
        console.log('Weak password');
        return res.status(400).json({ message: 'Password harus minimal 8 karakter, mengandung huruf besar, huruf kecil, angka, dan simbol.' });
    }

    const hashedPassword = bcrypt.hashSync(password, 10);
    console.log(`Hashed password: ${hashedPassword}`);
    const query = 'INSERT INTO users (email, nickname, password) VALUES (?, ?, ?)';

    connection.query(query, [email, nickname, hashedPassword], (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ message: 'Terjadi kesalahan saat mendaftar!' });
        }

        delete verificationCodes[email];
        console.log('Registration successful:', results);
        res.json({ message: 'Pendaftaran berhasil!' });
    });
});

// Menangani data login
app.post('/login', (req, res) => {
    const { email, password } = req.body;
    console.log(`Logging in with email: ${email}`);
    const query = 'SELECT * FROM users WHERE email = ?';

    connection.query(query, [email], (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ message: 'Terjadi kesalahan saat login!' });
        }

        if (results.length > 0) {
            const user = results[0];

            console.log(`Email: ${email}, Password: ${password}`);

            console.log(`User password from DB: ${user.password}`); // Password dari database
            const isPasswordValid = bcrypt.compareSync(password, user.password);
            console.log(`Hashed input password: ${password}`); // Password input yang di-hash
            console.log(`Password valid: ${isPasswordValid}`);

            if (isPasswordValid) {
                return res.json({ message: 'Login Berhasil!', redirect: '/' }); // Tambahkan redirect
            }

            else {
                console.log('Login failed: Incorrect password');
                res.status(401).json({ message: 'Login gagal! Email atau password salah.' });
            }
        } else {
            console.log('Login failed: Email not found');
            res.status(401).json({ message: 'Login gagal! Email atau password salah.' });
        }
    });
});

// Konfigurasi Nodemailer
const transporter = nodemailer.createTransport({
    host: 'smtp.gmail.com',
    port: 587,
    secure: false,
    auth: {
        user: process.env.EMAIL_USER, // Gunakan variabel lingkungan
        pass: process.env.EMAIL_PASS  // Gunakan variabel lingkungan
    }
});

// Fungsi untuk mengirim kode verifikasi
const sendVerificationCode = async (email, verificationCode) => {
    const mailOptions = {
        from: process.env.EMAIL_USER, // Ganti dengan email pengirim
        to: email,
        subject: 'Kode Verifikasi',
        text: `Kode verifikasi Anda adalah: ${verificationCode}`
    };

    return transporter.sendMail(mailOptions);
};

// Endpoint untuk mengirim kode verifikasi

app.post('/send-verification-code', async (req, res) => {
    const { email } = req.body;

    // Periksa apakah email sudah terdaftar
    const userQuery = 'SELECT * FROM users WHERE email = ?';
    connection.query(userQuery, [email], (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ message: 'Gagal memeriksa email.' });
        }
        if (results.length === 0) {
            return res.status(400).json({ message: 'Email tidak terdaftar.' });
        }
        // Lanjutkan dengan mengirim kode verifikasi
        const verificationCode = crypto.randomBytes(3).toString('hex');
        verificationCodes[email] = verificationCode;

        sendVerificationCode(email, verificationCode)
            .then(() => {
                res.json({ message: 'Kode verifikasi telah dikirim ke email Anda.' });
            })
            .catch(error => {
                console.error(error);
                res.status(500).json({ message: 'Gagal mengirim kode verifikasi.' });
            });
    });
});

// Endpoint untuk validasi kode verifikasi
app.post('/validate-verification-code', (req, res) => {
    const { email, code } = req.body; // Ambil email dan kode dari request body

    // Periksa apakah kode verifikasi yang diberikan sesuai
    if (verificationCodes[email] && verificationCodes[email] === code) {
        // Jika sesuai, hapus kode dari penyimpanan dan kirim respon sukses
        delete verificationCodes[email];
        res.json({ message: 'Kode verifikasi berhasil divalidasi.' });
    } else {
        // Jika tidak sesuai, kirim respon gagal
        res.status(400).json({ message: 'Kode verifikasi tidak valid!' });
    }
});
